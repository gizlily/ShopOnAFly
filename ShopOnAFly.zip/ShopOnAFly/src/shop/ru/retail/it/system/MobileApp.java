package shop.ru.retail.it.system;

public class MobileApp {
}
