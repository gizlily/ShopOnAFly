package shop.ru.retail;

import shop.ru.retail.goods.Cheese;
import shop.ru.retail.goods.DairyProducts;
import shop.ru.retail.goods.Kefir;
import shop.ru.retail.goods.Products;

import java.util.Arrays;
import java.util.List;

public class ShopRetailFly {
    private String shopName;

    public ShopRetailFly(String shopName) {
        this.shopName = shopName;   }

    public String getShopname() {
        return shopName;
    }
    public void setShopname(String shopname) {
        this.shopName = shopName;
    }
    public void checkShopName(){};

    public static void main(String[] args) {
        DairyProducts kefir = new Kefir("Родимая Сторонка","15.01.22","25.01.22",
                "12345","110","1.5",
                "Пластиковая бутылка","Козье молоко","1 литр");
        DairyProducts cheese = new Cheese("Ламбер","16.01.22","30.01.22",
                "23456","350","50%",
                "Вакуумная упакока","Коровье молоко","210 грамм");
        List<DairyProducts> product = Arrays.asList(kefir,cheese);
        for (DairyProducts p : product){ p.checkName(); }

    }












    }










