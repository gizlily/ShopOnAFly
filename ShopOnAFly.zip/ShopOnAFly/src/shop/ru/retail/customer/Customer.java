package shop.ru.retail.customer;

public class Customer {
}
